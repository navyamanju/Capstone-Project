<script>
    if(1==1)
    {
        let name='pfgfy';
    }
    console.log(name);
</script>