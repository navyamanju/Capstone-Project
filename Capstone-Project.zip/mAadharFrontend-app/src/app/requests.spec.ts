import { Requests } from './requests';

describe('Requests', () => {
  it('should create an instance', () => {
    expect(new Requests()).toBeTruthy();
  });
});
